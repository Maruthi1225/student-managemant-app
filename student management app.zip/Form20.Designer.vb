﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form20
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form20))
        Button2 = New Button()
        Button5 = New Button()
        MenuStrip1 = New MenuStrip()
        HOMEToolStripMenuItem = New ToolStripMenuItem()
        ToolStripMenuItem1 = New ToolStripMenuItem()
        FacultyToolStripMenuItem = New ToolStripMenuItem()
        DepartmentsToolStripMenuItem = New ToolStripMenuItem()
        GalaryToolStripMenuItem = New ToolStripMenuItem()
        FacultyLoginToolStripMenuItem = New ToolStripMenuItem()
        RegisterNewFacultyToolStripMenuItem = New ToolStripMenuItem()
        PictureBox1 = New PictureBox()
        Label32 = New Label()
        Label29 = New Label()
        Label30 = New Label()
        PictureBox16 = New PictureBox()
        Label31 = New Label()
        Panel5 = New Panel()
        Label59 = New Label()
        Label60 = New Label()
        Label61 = New Label()
        PictureBox3 = New PictureBox()
        PictureBox17 = New PictureBox()
        Label21 = New Label()
        Label22 = New Label()
        PictureBox12 = New PictureBox()
        Label23 = New Label()
        Label24 = New Label()
        PictureBox13 = New PictureBox()
        Label25 = New Label()
        Label26 = New Label()
        PictureBox14 = New PictureBox()
        Label27 = New Label()
        PictureBox15 = New PictureBox()
        Label13 = New Label()
        Label14 = New Label()
        PictureBox8 = New PictureBox()
        Label28 = New Label()
        Label15 = New Label()
        Label16 = New Label()
        PictureBox9 = New PictureBox()
        Label17 = New Label()
        Label18 = New Label()
        PictureBox10 = New PictureBox()
        Label19 = New Label()
        Label20 = New Label()
        PictureBox11 = New PictureBox()
        Label10 = New Label()
        PictureBox6 = New PictureBox()
        Label11 = New Label()
        Label9 = New Label()
        Label12 = New Label()
        Panel1 = New Panel()
        PictureBox7 = New PictureBox()
        Label7 = New Label()
        Label8 = New Label()
        PictureBox5 = New PictureBox()
        Label5 = New Label()
        Label6 = New Label()
        PictureBox4 = New PictureBox()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        PictureBox2 = New PictureBox()
        Label1 = New Label()
        MenuStrip1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox16, ComponentModel.ISupportInitialize).BeginInit()
        Panel5.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox17, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox13, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox14, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox15, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.White
        Button2.Cursor = Cursors.Hand
        Button2.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = Color.Black
        Button2.Location = New Point(10, 2)
        Button2.Margin = New Padding(2)
        Button2.Name = "Button2"
        Button2.Size = New Size(72, 32)
        Button2.TabIndex = 25
        Button2.Text = "BACK"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.Firebrick
        Button5.Cursor = Cursors.Hand
        Button5.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Button5.ForeColor = Color.White
        Button5.Location = New Point(1870, -1)
        Button5.Margin = New Padding(2)
        Button5.Name = "Button5"
        Button5.Size = New Size(46, 33)
        Button5.TabIndex = 24
        Button5.Text = "X"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' MenuStrip1
        ' 
        MenuStrip1.BackColor = Color.White
        MenuStrip1.Dock = DockStyle.None
        MenuStrip1.Font = New Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point)
        MenuStrip1.Items.AddRange(New ToolStripItem() {HOMEToolStripMenuItem, ToolStripMenuItem1, FacultyToolStripMenuItem, DepartmentsToolStripMenuItem, GalaryToolStripMenuItem, FacultyLoginToolStripMenuItem, RegisterNewFacultyToolStripMenuItem})
        MenuStrip1.Location = New Point(988, 81)
        MenuStrip1.Name = "MenuStrip1"
        MenuStrip1.Size = New Size(931, 40)
        MenuStrip1.TabIndex = 18
        MenuStrip1.Text = "MenuStrip1"
        ' 
        ' HOMEToolStripMenuItem
        ' 
        HOMEToolStripMenuItem.Name = "HOMEToolStripMenuItem"
        HOMEToolStripMenuItem.Size = New Size(91, 36)
        HOMEToolStripMenuItem.Text = "Home"
        ' 
        ' ToolStripMenuItem1
        ' 
        ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        ToolStripMenuItem1.Size = New Size(122, 36)
        ToolStripMenuItem1.Text = "About us"
        ' 
        ' FacultyToolStripMenuItem
        ' 
        FacultyToolStripMenuItem.Name = "FacultyToolStripMenuItem"
        FacultyToolStripMenuItem.Size = New Size(100, 36)
        FacultyToolStripMenuItem.Text = "Faculty"
        ' 
        ' DepartmentsToolStripMenuItem
        ' 
        DepartmentsToolStripMenuItem.Name = "DepartmentsToolStripMenuItem"
        DepartmentsToolStripMenuItem.Size = New Size(110, 36)
        DepartmentsToolStripMenuItem.Text = "Courses"
        ' 
        ' GalaryToolStripMenuItem
        ' 
        GalaryToolStripMenuItem.Name = "GalaryToolStripMenuItem"
        GalaryToolStripMenuItem.Size = New Size(99, 36)
        GalaryToolStripMenuItem.Text = "Gallery"
        ' 
        ' FacultyLoginToolStripMenuItem
        ' 
        FacultyLoginToolStripMenuItem.BackColor = Color.White
        FacultyLoginToolStripMenuItem.ForeColor = Color.Red
        FacultyLoginToolStripMenuItem.Name = "FacultyLoginToolStripMenuItem"
        FacultyLoginToolStripMenuItem.Size = New Size(161, 36)
        FacultyLoginToolStripMenuItem.Text = "Faculty login"
        ' 
        ' RegisterNewFacultyToolStripMenuItem
        ' 
        RegisterNewFacultyToolStripMenuItem.ForeColor = Color.Red
        RegisterNewFacultyToolStripMenuItem.Name = "RegisterNewFacultyToolStripMenuItem"
        RegisterNewFacultyToolStripMenuItem.Size = New Size(240, 36)
        RegisterNewFacultyToolStripMenuItem.Text = "Register new faculty"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.Location = New Point(115, 11)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Padding = New Padding(10)
        PictureBox1.Size = New Size(507, 113)
        PictureBox1.TabIndex = 13
        PictureBox1.TabStop = False
        ' 
        ' Label32
        ' 
        Label32.AutoSize = True
        Label32.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label32.Location = New Point(1694, 491)
        Label32.Name = "Label32"
        Label32.Size = New Size(87, 20)
        Label32.TabIndex = 275
        Label32.Text = "---NAME---"
        ' 
        ' Label29
        ' 
        Label29.AutoSize = True
        Label29.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label29.Location = New Point(1674, 823)
        Label29.Name = "Label29"
        Label29.Size = New Size(140, 20)
        Label29.TabIndex = 279
        Label29.Text = "---QULIFICATION---"
        ' 
        ' Label30
        ' 
        Label30.AutoSize = True
        Label30.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label30.Location = New Point(1694, 803)
        Label30.Name = "Label30"
        Label30.Size = New Size(87, 20)
        Label30.TabIndex = 278
        Label30.Text = "---NAME---"
        ' 
        ' PictureBox16
        ' 
        PictureBox16.Image = CType(resources.GetObject("PictureBox16.Image"), Image)
        PictureBox16.Location = New Point(1674, 607)
        PictureBox16.Name = "PictureBox16"
        PictureBox16.Size = New Size(146, 193)
        PictureBox16.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox16.TabIndex = 277
        PictureBox16.TabStop = False
        ' 
        ' Label31
        ' 
        Label31.AutoSize = True
        Label31.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label31.Location = New Point(1674, 511)
        Label31.Name = "Label31"
        Label31.Size = New Size(140, 20)
        Label31.TabIndex = 276
        Label31.Text = "---QULIFICATION---"
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.White
        Panel5.BorderStyle = BorderStyle.FixedSingle
        Panel5.Controls.Add(Label59)
        Panel5.Controls.Add(Label60)
        Panel5.Controls.Add(Label61)
        Panel5.Location = New Point(-1, 1005)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(1935, 76)
        Panel5.TabIndex = 273
        ' 
        ' Label59
        ' 
        Label59.AutoSize = True
        Label59.Location = New Point(1750, 32)
        Label59.Name = "Label59"
        Label59.Size = New Size(141, 15)
        Label59.TabIndex = 2
        Label59.Text = "vaagdevicollages@edu.in"
        ' 
        ' Label60
        ' 
        Label60.AutoSize = True
        Label60.Location = New Point(1584, 32)
        Label60.Name = "Label60"
        Label60.Size = New Size(139, 15)
        Label60.TabIndex = 1
        Label60.Text = "contact us : 00000000 /00"
        ' 
        ' Label61
        ' 
        Label61.AutoSize = True
        Label61.BorderStyle = BorderStyle.FixedSingle
        Label61.Location = New Point(42, 30)
        Label61.Name = "Label61"
        Label61.Size = New Size(110, 17)
        Label61.TabIndex = 0
        Label61.Text = "@vaagdevicollages"
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.Transparent
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(623, 11)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(114, 109)
        PictureBox3.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox3.TabIndex = 17
        PictureBox3.TabStop = False
        ' 
        ' PictureBox17
        ' 
        PictureBox17.Image = CType(resources.GetObject("PictureBox17.Image"), Image)
        PictureBox17.Location = New Point(1674, 295)
        PictureBox17.Name = "PictureBox17"
        PictureBox17.Size = New Size(146, 193)
        PictureBox17.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox17.TabIndex = 274
        PictureBox17.TabStop = False
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label21.Location = New Point(1481, 823)
        Label21.Name = "Label21"
        Label21.Size = New Size(140, 20)
        Label21.TabIndex = 272
        Label21.Text = "---QULIFICATION---"
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label22.Location = New Point(1501, 803)
        Label22.Name = "Label22"
        Label22.Size = New Size(87, 20)
        Label22.TabIndex = 271
        Label22.Text = "---NAME---"
        ' 
        ' PictureBox12
        ' 
        PictureBox12.Image = CType(resources.GetObject("PictureBox12.Image"), Image)
        PictureBox12.Location = New Point(1481, 607)
        PictureBox12.Name = "PictureBox12"
        PictureBox12.Size = New Size(146, 193)
        PictureBox12.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox12.TabIndex = 270
        PictureBox12.TabStop = False
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label23.Location = New Point(1481, 511)
        Label23.Name = "Label23"
        Label23.Size = New Size(140, 20)
        Label23.TabIndex = 269
        Label23.Text = "---QULIFICATION---"
        ' 
        ' Label24
        ' 
        Label24.AutoSize = True
        Label24.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label24.Location = New Point(1501, 491)
        Label24.Name = "Label24"
        Label24.Size = New Size(87, 20)
        Label24.TabIndex = 268
        Label24.Text = "---NAME---"
        ' 
        ' PictureBox13
        ' 
        PictureBox13.Image = CType(resources.GetObject("PictureBox13.Image"), Image)
        PictureBox13.Location = New Point(1481, 295)
        PictureBox13.Name = "PictureBox13"
        PictureBox13.Size = New Size(146, 193)
        PictureBox13.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox13.TabIndex = 267
        PictureBox13.TabStop = False
        ' 
        ' Label25
        ' 
        Label25.AutoSize = True
        Label25.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label25.Location = New Point(1280, 823)
        Label25.Name = "Label25"
        Label25.Size = New Size(140, 20)
        Label25.TabIndex = 266
        Label25.Text = "---QULIFICATION---"
        ' 
        ' Label26
        ' 
        Label26.AutoSize = True
        Label26.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label26.Location = New Point(1309, 803)
        Label26.Name = "Label26"
        Label26.Size = New Size(87, 20)
        Label26.TabIndex = 265
        Label26.Text = "---NAME---"
        ' 
        ' PictureBox14
        ' 
        PictureBox14.Image = CType(resources.GetObject("PictureBox14.Image"), Image)
        PictureBox14.Location = New Point(1280, 607)
        PictureBox14.Name = "PictureBox14"
        PictureBox14.Size = New Size(146, 193)
        PictureBox14.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox14.TabIndex = 264
        PictureBox14.TabStop = False
        ' 
        ' Label27
        ' 
        Label27.AutoSize = True
        Label27.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label27.Location = New Point(1280, 511)
        Label27.Name = "Label27"
        Label27.Size = New Size(140, 20)
        Label27.TabIndex = 263
        Label27.Text = "---QULIFICATION---"
        ' 
        ' PictureBox15
        ' 
        PictureBox15.Image = CType(resources.GetObject("PictureBox15.Image"), Image)
        PictureBox15.Location = New Point(1280, 295)
        PictureBox15.Name = "PictureBox15"
        PictureBox15.Size = New Size(146, 193)
        PictureBox15.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox15.TabIndex = 261
        PictureBox15.TabStop = False
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label13.Location = New Point(1084, 823)
        Label13.Name = "Label13"
        Label13.Size = New Size(140, 20)
        Label13.TabIndex = 260
        Label13.Text = "---QULIFICATION---"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label14.Location = New Point(1104, 803)
        Label14.Name = "Label14"
        Label14.Size = New Size(87, 20)
        Label14.TabIndex = 259
        Label14.Text = "---NAME---"
        ' 
        ' PictureBox8
        ' 
        PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), Image)
        PictureBox8.Location = New Point(1084, 607)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(146, 193)
        PictureBox8.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox8.TabIndex = 258
        PictureBox8.TabStop = False
        ' 
        ' Label28
        ' 
        Label28.AutoSize = True
        Label28.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label28.Location = New Point(1309, 491)
        Label28.Name = "Label28"
        Label28.Size = New Size(87, 20)
        Label28.TabIndex = 262
        Label28.Text = "---NAME---"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label15.Location = New Point(1084, 511)
        Label15.Name = "Label15"
        Label15.Size = New Size(140, 20)
        Label15.TabIndex = 257
        Label15.Text = "---QULIFICATION---"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label16.Location = New Point(1104, 491)
        Label16.Name = "Label16"
        Label16.Size = New Size(87, 20)
        Label16.TabIndex = 256
        Label16.Text = "---NAME---"
        ' 
        ' PictureBox9
        ' 
        PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), Image)
        PictureBox9.Location = New Point(1084, 295)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(146, 193)
        PictureBox9.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox9.TabIndex = 255
        PictureBox9.TabStop = False
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label17.Location = New Point(883, 823)
        Label17.Name = "Label17"
        Label17.Size = New Size(140, 20)
        Label17.TabIndex = 254
        Label17.Text = "---QULIFICATION---"
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label18.Location = New Point(912, 803)
        Label18.Name = "Label18"
        Label18.Size = New Size(87, 20)
        Label18.TabIndex = 253
        Label18.Text = "---NAME---"
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), Image)
        PictureBox10.Location = New Point(883, 607)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(146, 193)
        PictureBox10.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox10.TabIndex = 252
        PictureBox10.TabStop = False
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label19.Location = New Point(883, 511)
        Label19.Name = "Label19"
        Label19.Size = New Size(140, 20)
        Label19.TabIndex = 251
        Label19.Text = "---QULIFICATION---"
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label20.Location = New Point(912, 491)
        Label20.Name = "Label20"
        Label20.Size = New Size(87, 20)
        Label20.TabIndex = 250
        Label20.Text = "---NAME---"
        ' 
        ' PictureBox11
        ' 
        PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), Image)
        PictureBox11.Location = New Point(883, 295)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(146, 193)
        PictureBox11.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox11.TabIndex = 249
        PictureBox11.TabStop = False
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label10.Location = New Point(691, 803)
        Label10.Name = "Label10"
        Label10.Size = New Size(87, 20)
        Label10.TabIndex = 247
        Label10.Text = "---NAME---"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), Image)
        PictureBox6.Location = New Point(671, 607)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(146, 193)
        PictureBox6.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox6.TabIndex = 246
        PictureBox6.TabStop = False
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label11.Location = New Point(671, 511)
        Label11.Name = "Label11"
        Label11.Size = New Size(140, 20)
        Label11.TabIndex = 245
        Label11.Text = "---QULIFICATION---"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label9.Location = New Point(671, 823)
        Label9.Name = "Label9"
        Label9.Size = New Size(140, 20)
        Label9.TabIndex = 248
        Label9.Text = "---QULIFICATION---"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label12.Location = New Point(691, 491)
        Label12.Name = "Label12"
        Label12.Size = New Size(87, 20)
        Label12.TabIndex = 244
        Label12.Text = "---NAME---"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.White
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(MenuStrip1)
        Panel1.Controls.Add(PictureBox3)
        Panel1.Location = New Point(-1, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1942, 125)
        Panel1.TabIndex = 231
        ' 
        ' PictureBox7
        ' 
        PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), Image)
        PictureBox7.Location = New Point(671, 295)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(146, 193)
        PictureBox7.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox7.TabIndex = 243
        PictureBox7.TabStop = False
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label7.Location = New Point(463, 823)
        Label7.Name = "Label7"
        Label7.Size = New Size(140, 20)
        Label7.TabIndex = 242
        Label7.Text = "---QULIFICATION---"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label8.Location = New Point(492, 803)
        Label8.Name = "Label8"
        Label8.Size = New Size(87, 20)
        Label8.TabIndex = 241
        Label8.Text = "---NAME---"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(463, 607)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(146, 193)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 240
        PictureBox5.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label5.Location = New Point(463, 511)
        Label5.Name = "Label5"
        Label5.Size = New Size(140, 20)
        Label5.TabIndex = 239
        Label5.Text = "---QULIFICATION---"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point)
        Label6.Location = New Point(492, 491)
        Label6.Name = "Label6"
        Label6.Size = New Size(87, 20)
        Label6.TabIndex = 238
        Label6.Text = "---NAME---"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), Image)
        PictureBox4.Location = New Point(463, 295)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(146, 193)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 237
        PictureBox4.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point)
        Label4.Location = New Point(85, 802)
        Label4.Name = "Label4"
        Label4.Size = New Size(226, 32)
        Label4.TabIndex = 236
        Label4.Text = "---QULIFICATION---"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point)
        Label3.Location = New Point(115, 758)
        Label3.Name = "Label3"
        Label3.Size = New Size(141, 32)
        Label3.TabIndex = 235
        Label3.Text = "---NAME---"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(63, 300)
        Label2.Name = "Label2"
        Label2.Size = New Size(307, 30)
        Label2.TabIndex = 234
        Label2.Text = "HEAD OF THE DEPARTMENT"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(52, 348)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(318, 396)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 233
        PictureBox2.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Arial Rounded MT Bold", 36F, FontStyle.Underline, GraphicsUnit.Point)
        Label1.Location = New Point(444, 165)
        Label1.Name = "Label1"
        Label1.Size = New Size(1133, 55)
        Label1.TabIndex = 232
        Label1.Text = "DEPARTMENT OF COMMERCE / MANAGEMENT"
        ' 
        ' Form20
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1940, 1080)
        Controls.Add(Label32)
        Controls.Add(Label29)
        Controls.Add(Label30)
        Controls.Add(PictureBox16)
        Controls.Add(Label31)
        Controls.Add(Panel5)
        Controls.Add(PictureBox17)
        Controls.Add(Label21)
        Controls.Add(Label22)
        Controls.Add(PictureBox12)
        Controls.Add(Label23)
        Controls.Add(Label24)
        Controls.Add(PictureBox13)
        Controls.Add(Label25)
        Controls.Add(Label26)
        Controls.Add(PictureBox14)
        Controls.Add(Label27)
        Controls.Add(PictureBox15)
        Controls.Add(Label13)
        Controls.Add(Label14)
        Controls.Add(PictureBox8)
        Controls.Add(Label28)
        Controls.Add(Label15)
        Controls.Add(Label16)
        Controls.Add(PictureBox9)
        Controls.Add(Label17)
        Controls.Add(Label18)
        Controls.Add(PictureBox10)
        Controls.Add(Label19)
        Controls.Add(Label20)
        Controls.Add(PictureBox11)
        Controls.Add(Label10)
        Controls.Add(PictureBox6)
        Controls.Add(Label11)
        Controls.Add(Label9)
        Controls.Add(Label12)
        Controls.Add(Panel1)
        Controls.Add(PictureBox7)
        Controls.Add(Label7)
        Controls.Add(Label8)
        Controls.Add(PictureBox5)
        Controls.Add(Label5)
        Controls.Add(Label6)
        Controls.Add(PictureBox4)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox2)
        Controls.Add(Label1)
        FormBorderStyle = FormBorderStyle.None
        Name = "Form20"
        Text = "Form20"
        MenuStrip1.ResumeLayout(False)
        MenuStrip1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox16, ComponentModel.ISupportInitialize).EndInit()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox17, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox13, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox14, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox15, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents HOMEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents FacultyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DepartmentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GalaryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FacultyLoginToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegisterNewFacultyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox17 As PictureBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents Label27 As Label
    Friend WithEvents PictureBox15 As PictureBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label1 As Label
End Class
